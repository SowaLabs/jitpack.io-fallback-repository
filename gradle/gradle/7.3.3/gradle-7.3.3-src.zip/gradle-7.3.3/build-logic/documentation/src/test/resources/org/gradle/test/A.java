package org.gradle.test;

class A {
}
