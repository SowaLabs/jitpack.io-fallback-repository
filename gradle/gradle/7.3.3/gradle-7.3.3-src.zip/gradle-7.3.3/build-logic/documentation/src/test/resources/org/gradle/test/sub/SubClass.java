package org.gradle.test.sub;

public class SubClass {
}
